//package com.yash.service;
//
//import java.util.List;
//
//import com.yash.model.Product;
//import com.yash.model.ProductUser;
//
//import com.yash.repository.ProductUserRepo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
////defining the business logic
//@Service
//public class ProductUserService {
//
//	@Autowired
//	private ProductUserRepo productUserRepo;
//
//	
//	// getting all user record by using the method findaAll() of CrudRepository
//	public List<ProductUser> getAllUser() {
//		return productUserRepo.findAll();
//	}
//
//	
//	//Find by emailId logic  
//	public ProductUser findByEmailId(String emailId) {
//		// TODO Auto-generated method stub
//		return productUserRepo.findByEmailId(emailId);
//	}
//
//}
