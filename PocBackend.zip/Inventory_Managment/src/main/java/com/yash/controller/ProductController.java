package com.yash.controller;

import java.util.List;
import java.util.Optional;

import com.yash.model.Product;
import com.yash.repository.ProductRepo;
import com.yash.service.ProductService;
import com.yash.service.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("product")
@CrossOrigin("*")
public class ProductController {

	@Autowired
	private ProductRepo productRepo;

	@Autowired
	private ProductService productService;

	// http://localhost:8080/product/getAll
	// creating a get mapping that retrieves all the detail from the database
	@GetMapping("/getAll")
	public List<Product> getAllProductList() {
		return productService.getAllProducts();
	}

	// creating a get mapping that retrieves the detail of a specific product
	// http://localhost:8080/product/getById/7
	@GetMapping("/getById/{productId}")
	public Product getProductById(@PathVariable int productId) throws ResourceNotFoundException {
		return productService.getProductById(productId);

	}

	// http://localhost:8080/product/saveProduct
	// creating post mapping that post the product detail in the database
	@PostMapping("saveProduct")
	public ResponseEntity<Product> saveProductDeatils(@RequestBody Product product) {

		Product saveProduct = productService.saveProduct(product);
		return new ResponseEntity<Product>(saveProduct, HttpStatus.CREATED);

	}

//http://localhost:8080/product/deleteProduct/16
	// creating a delete mapping that deletes a specified product
	@DeleteMapping("deleteProduct/{productId}")
	public String deleteProduct(@PathVariable int productId) {
		return productService.deleteProduct(productId);

	}

	// creating put mapping that updates the product details
//http://localhost:8080/product/updateProduct/16
	@PutMapping("updateProduct/{productId}")
	public ResponseEntity<Product> updateProdquct(@RequestBody Product product, @PathVariable int productId) {
		Product product1 = productService.getProductById(productId);

		product1.setProductDescription(product.getProductDescription());
		product1.setProductName(product.getProductName());
		product1.setProductPrice(product.getProductPrice());
		product1.setQuantity(product.getQuantity());
		product1.setStatus(product.getStatus());

		Product updateProduct = productService.saveProduct(product1);
		return ResponseEntity.ok().body(updateProduct);

	}

	// http://localhost:8080/product/search?query=key
	@GetMapping("/search")
	public ResponseEntity<List<Product>> searchProducts(@RequestParam("query") String query) {
		return ResponseEntity.ok(productService.searchProduct(query));
	}

	// http://localhost:8080/product/getByproductPrice/1/3
	// Pagination and Sorting on the basis of role
	@GetMapping("/getByproductPrice/{pageno}/{count}")
	public List<Product> getAllProductPaging(@PathVariable int pageno, @PathVariable int count) {
		return productService.getAllProducts(pageno, count);
	}

}
