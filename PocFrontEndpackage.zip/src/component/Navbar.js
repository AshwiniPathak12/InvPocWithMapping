import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import "./Navbar.css"
//import axios from "axios";
//import { useEffect, useState } from "react";

// const searchCategory = (query) => {
//   return axios.get(`http://localhost:8083/category/search?`, {
//     params: {
//       query,
//     },
//   });
// }; 



const Navbar = () => {
  // const [categories, setCategories] = useState([]);

  // const handleSearch = (query) => {
  //   searchCategory(query).then((response) => {
  //     setCategories(response.data);
  //   });
  // }

  const allCount = useSelector((state) => state.app.productCats);
  return (
    <div className="clr">
      <div >
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <h5 className="navbar-brand">Navbar</h5>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto">
              <li className="nav-item active">
                <Link to="/" className="nav-link">
                  Create Product
                </Link>

               
              </li>
              <li className="nav-item active">
                <Link to="/read" className="nav-link">
                  All Product({allCount?.length})
                </Link>
              </li>

              <input
                classNameName="form-control me-2 w-50"
                type="search"
                placeholder="search"
                aria-label="Search"             

                />
              {/* <div>
                <input type="text" placeholder="Enter category name" />
                <button onClick={handleSearch}>Search</button>
                <ul>
                  {categories.map((category) => (
                    <li key={category.id}>{category.name}</li>
                  ))}
                </ul>
              </div> */}
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};


export default Navbar;
