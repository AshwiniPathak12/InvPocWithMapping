import React from "react";
import axios from "axios";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

//create action
//create product Category
export const createProductCat = createAsyncThunk(
  "createPrductCat",
  async (data, { rejectWithValue }) => {
    // console.log("call success...!!", data);
    const response = await axios.post(
      `http://localhost:8083/category/saveCategory`,
      data
    );
    //console.log("response data", response.data);
    return response.data;
  }
);

//Read Action

export const showProductCat = createAsyncThunk(
  "showProductCat",
  async (data, { rejectWithValue }) => {
    // console.log("call success...!!", data);
    const response = await axios.get(`http://localhost:8083/category/getAll`);
    //console.log("response data", response.data);
    return response.data;
  }
);

//Delete Action
export const deleteProductCat = createAsyncThunk(
  "deleteProductCat",
  async (categoryId, { rejectWithValue }) => {
    // console.log("call success...!!", data);
    const response = await axios.delete(
      `http://localhost:8083/category/deleteProduct/${categoryId}`
    );
    //console.log("response data", response.data);
    return response.data;
  }
);

//Update
// export const updateProductCat  = createAsyncThunk(
//   "updateProductCat",
//   async (categoryId, { rejectWithValue }) => {
//     // console.log("call success...!!", data);
//     const response = await axios.put(
//       `http://localhost:8083/category/updateCategory/${categoryId}`
//     );
//     //console.log("response data", response.data);
//     return response.data;
//   }
// );

export const productcatslice = createSlice({
  name: "productcatslice",
  initialState: {
    // productsCat: [productsCatInt],
    productsCat: [],
    loading: false,
    error: null,
  },
  extraReducers: {
    //Create Asynchthunk is basically middleware use it when need to handle api
    //this return promises which us handle using 3 things i.e pending,reject,fullfill
    //createProduct ExtraReducers
    [createProductCat.pending]: (state) => {
      state.loading = true;
    },
    [createProductCat.fulfilled]: (state, action) => {
      //console.log("action", action);
      //console.log("state", state);
      state.loading = false;
      //console.log(action.payload);
      //console.log("init" ,state.initialState.productCat);
      state.productsCat.push(action.payload);
      //state.initialState.productsCat.push(action.payload);

      //  console.log(state.productCats);
    },
    [createProductCat.rejected]: (state, action) => {
      state.loading = false;
      state.productCats = action.payload;
    },

    //Read
    [showProductCat.pending]: (state) => {
      state.loading = true;
    },
    [showProductCat.fulfilled]: (state, action) => {
      state.loading = false;

      state.productCats = action.payload;
    },
    [showProductCat.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },

    //Delete

    [deleteProductCat.pending]: (state) => {
      state.loading = true;
    },
    [deleteProductCat.fulfilled]: (state, action) => {
      state.loading = false;
      const { categoryId } = action.payload;
      if (categoryId) {
        state.productCats = state.productCats.filter(
          (ele) => ele.categoryId !== categoryId
        );
      }
      console.log("Delete Action..!!", action.payload);
      alert("Delete Action..!!");
      // state.productCats = action.payload;
    },
    [deleteProductCat.rejected]: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },

    //Update
    // [updateProductCat.pending]: (state) => {
    //   state.loading = true;
    // },
    // [updateProductCat.fulfilled]: (state, action) => {
     
    //   state.loading = false;
    //   state.productsCat = state.productCats.map((ele)=>
    //   ele.categoryId === action.payload.categoryId ? action.payload:ele);
      
    //   //state.productsCat.push(action.payload);
      
    // },
    // [updateProductCat.rejected]: (state, action) => {
    //   state.loading = false;
    //   state.productCats = action.payload;
    // },

  },
});

export default productcatslice.reducer;
