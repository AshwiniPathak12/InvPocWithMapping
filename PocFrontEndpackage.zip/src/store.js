import { configureStore } from "@reduxjs/toolkit";
import productcatslice from "./feature/productcatslice"

export const store = configureStore({
    reducer: {
      app:productcatslice ,    
    },
  });

  