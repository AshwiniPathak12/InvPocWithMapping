//package com.yash.model;
//
//public enum Status {
//
//
//	SUCCESS,
//    Admin_ALREADY_EXISTS,
//    FAILURE
//}
