package com.yash.service;

import java.util.List;
import java.util.Optional;

import com.yash.model.Category;
import com.yash.model.Product;
import com.yash.repository.CategoryRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class CategoryService {

	@Autowired
	CategoryRepo categoryRepo;

	public List<Category> getAllCategory() {
		return categoryRepo.findAll();
	}

	// getting a specific record by using the method findById() of CrudRepository
	public Category getCategoryById(@PathVariable int categoryId) throws ResourceNotFoundException {
		return categoryRepo.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("This Product Id Does Not Exists " + categoryId));

	}

	// saving a specific record by using the method save() of CrudRepository
	public Category saveCategory(@RequestBody Category category) {
		Category saveCategory = categoryRepo.save(category);
		return saveCategory;
	}

	//// deleting a specific record by using the method deleteById() of
	//// CrudRepository
	public String deleteCategory(@PathVariable int categoryId) {
		Optional<Category> optionalCategory = categoryRepo.findById(categoryId);

		if (optionalCategory.isPresent()) {
			categoryRepo.deleteById(categoryId);
		} else {
			throw new ResourceNotFoundException("This Product Id Does Not Exists " + categoryId);
		}
		return "Deleted Successfully..!!!";
	}

	// updating a record
	Category updateCategory(Category category, int categoryId) {
		return categoryRepo.save(category);

	}

	// Searching a particular product
		public List<Category> searchCat(String query) {
			List<Category> categorys = categoryRepo.searchCategory(query);
			return categorys;
		}
}
