package com.yash.repository;

import java.util.List;

import com.yash.model.Category;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepo extends JpaRepository<Category, Integer> {

	@Query("SELECT u FROM Category u WHERE u.categoryName LIKE CONCAT('%',:query, '%')")
	List<Category> searchCategory(String query);


}
