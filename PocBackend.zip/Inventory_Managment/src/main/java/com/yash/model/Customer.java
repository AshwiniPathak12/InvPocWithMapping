//package com.yash.model;
//
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//
//@Entity
//public class Customer {
//
//	@Id
//
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private int customerId;
//	private String firstName;
//	private String lastName;
//	private String address;
//	private String email;
//	private String mobileNo;
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name = "order_customer_fk")
//	private List<Order> order;
//
//}
