//package com.yash.model;
//
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//
////mark class as an Entity  
//@Entity
//public class ProductRole {
//	
//	// Defining as primary key 
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//	private String roleName;
//
//	public ProductRole() {
//
//	}
//
//	public ProductRole(int id, String roleName) {
//		super();
//		this.id = id;
//		this.roleName = roleName;
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getRoleName() {
//		return roleName;
//	}
//
//	public void setRoleName(String roleName) {
//		this.roleName = roleName;
//	}
//
//	@Override
//	public String toString() {
//		return "MyUserRole [id=" + id + ", roleName=" + roleName + "]";
//	}
//
//}
