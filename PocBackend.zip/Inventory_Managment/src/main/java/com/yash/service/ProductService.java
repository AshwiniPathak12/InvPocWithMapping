package com.yash.service;

import java.util.List;
import java.util.Optional;

import com.yash.model.Product;
import com.yash.repository.ProductRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

//defining the business logic
@Service
public class ProductService {

	@Autowired
	private ProductRepo productRepo;

	// getting all product record by using the method findaAll() of CrudRepository
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	// getting a specific record by using the method findById() of CrudRepository
	public Product getProductById(@PathVariable int productId) throws ResourceNotFoundException {
		return productRepo.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("This Product Id Does Not Exists " + productId));

	}

	// saving a specific record by using the method save() of CrudRepository
	public Product saveProduct(@RequestBody Product product) {
		Product saveProduct = productRepo.save(product);
		return saveProduct;
	}

	//// deleting a specific record by using the method deleteById() of
	//// CrudRepository
	public String deleteProduct(@PathVariable int productId) {
		Optional<Product> optionalProduct = productRepo.findById(productId);

		if (optionalProduct.isPresent()) {
			productRepo.deleteById(productId);
		} else {
			throw new ResourceNotFoundException("This Product Id Does Not Exists " + productId);
		}
		return "Deleted Successfully..!!!";
	}

	// updating a record
	Product updateProduct(Product product, int productId) {
		return productRepo.save(product);

	}

	// Searching a particular product
	public List<Product> searchProduct(String query) {
		List<Product> products = productRepo.searchProduct(query);
		return products;
	}

	// Pagination
	public List<Product> getAllProducts(int pageno, int count) {
		Pageable pagable = PageRequest.of(pageno, count);
		return productRepo.findAll(pagable).get().toList();

	}

}

