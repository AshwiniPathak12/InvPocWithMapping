package com.yash.repository;

import java.util.List;

import com.yash.model.Product;
//import com.yash.model.ProductUser;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository

public interface ProductRepo extends JpaRepository<Product, Integer> {

	// shubhi
	// List<Product> searchByProductName(String productName);

	@Query("SELECT u FROM Product u WHERE u.productName LIKE CONCAT('%',:query, '%')")
	List<Product> searchProduct(String query);

}
