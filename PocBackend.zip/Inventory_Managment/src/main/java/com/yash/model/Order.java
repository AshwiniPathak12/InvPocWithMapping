//package com.yash.model;
//
//import java.util.Date;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "Orders")
//public class Order {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private int orderId;
//	private Date orderDate;
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name = "orderDetails_order_fk")
//	private List<OrderDetails> orderDetails;
//
//}
