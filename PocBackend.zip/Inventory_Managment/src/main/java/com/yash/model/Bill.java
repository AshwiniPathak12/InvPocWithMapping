//package com.yash.model;
//
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
//
//@Entity
//public class Bill {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private int billNumber;
//	private String paymenType;
//	private String billType;
//
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name = "orderDetails_bill_fk")
//	private List<OrderDetails> orderDetails;
//
//}
