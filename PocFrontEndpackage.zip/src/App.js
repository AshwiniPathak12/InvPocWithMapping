
import "./App.css";
import Navbar from "./component/Navbar";
import Create from "./component/Pages/Create";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Read from "./component/Pages/Read";
import Update from "./component/Pages/Update";


function App() {
 
  return (
    <div className="App">    
      <BrowserRouter>
      <Navbar/>
        <Routes>
          <Route path="/" element={<Create />}></Route>
          
          <Route path="/read" element={<Read />}></Route>
          <Route path="/update/:categoryId" element={<Update />}></Route>
        </Routes>
      </BrowserRouter>
      <div>
      
   
      </div>
    </div>
  );
}

export default App;
