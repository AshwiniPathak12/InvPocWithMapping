//package com.yash.controller;
//
//import java.util.List;
//
//import com.yash.model.ProductUser;
//import com.yash.model.Status;
//import com.yash.repository.ProductUserRepo;
//import com.yash.service.ProductUserService;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("user")
//@CrossOrigin("*")
//public class ProductUserController {
//
//	@Autowired
//	private ProductUserService productUserService;
//
////
////	@Autowired
////	private ProductUserRepo productUserRepo;
////http://localhost:8080/user/getAll
//	// creating a get mapping that retrieves all the detail from the database
//	@GetMapping("getAll")
//	public List<ProductUser> getAllUser() {
//		return productUserService.getAllUser();
//	}
//
//	//http://localhost:8080/user/login
//	// Login rest api
//	@CrossOrigin("*")
//	@PostMapping("/login")
//	public Status loginProduct(@RequestBody ProductUser productUser) {
//		System.out.println(productUser);
////	String email=productUser.getEmailId();
//		ProductUser oldProductUser = productUserService.findByEmailId(productUser.getEmailId());
//		System.out.println(oldProductUser);
//		if (oldProductUser != null) {
//			if (oldProductUser.getPassword().equals(productUser.getPassword())) {
//				return Status.SUCCESS;
//			} else {
//				return Status.FAILURE;
//			}
//		}
//		return Status.FAILURE;
//	}
//}
