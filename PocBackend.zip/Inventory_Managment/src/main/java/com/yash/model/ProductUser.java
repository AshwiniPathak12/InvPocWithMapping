//package com.yash.model;
//
//import javax.persistence.Entity;
//
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//
////mark class as an Entity  
//@JsonIgnoreProperties({ "hibernateLazyInitializer" }) // because error while fetch data by id
//@Entity
//public class ProductUser {
//
//	
//	// Defining as primary key 
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//	private String emailId;
//	private String password;
//	//  private String username;
//
//	@ManyToOne(fetch = FetchType.EAGER)
//	// @JoinColumn(name = "id", referencedColumnName = "id")
//	private ProductRole productRole;
//
//	public ProductUser() {
//	}
//
//	public ProductUser(int id, String emailId, String password, ProductRole productRole) {
//		super();
//		this.id = id;
//		this.emailId = emailId;
//		this.password = password;
//		this.productRole = productRole;
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getEmailId() {
//		return emailId;
//	}
//
//	public void setEmailId(String emailId) {
//		this.emailId = emailId;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public ProductRole getProductRole() {
//		return productRole;
//	}
//
//	public void setProductRole(ProductRole productRole) {
//		this.productRole = productRole;
//	}
//
//	@Override
//	public String toString() {
//		return "ProductUser [id=" + id + ", emailId=" + emailId + ", password=" + password + ", productRole="
//				+ productRole + "]";
//	}
//
//}
