import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { showProductCat , deleteProductCat} from "../../feature/productcatslice";
import "./Read.css";
import { Link } from "react-router-dom";
import Button from "../UI/Button"

const Read = () => {
  const dispatch = useDispatch();
  //If not productsCats
  const {productCats }= useSelector((state) => state.app);
  console.log("data is", productCats);
  useEffect(() => {
    dispatch(showProductCat());
  });

  // if (loading) {
  //   return <h2>Loading</h2>;
  // }

  return (
    <React.Fragment>
    <div className="k">
      <h2 className="h2Data">All Data</h2>
     
      <div className="trf">
        <table className="td">
          <thead className="th">
            <tr>
              <th>categoryId</th>
              <th>categoryName</th>
              <th>productId</th>
              <th>productName</th>
              <th>productDescription</th>
              <th>productPrice</th>
              <th>quantity</th>
              <th>status</th>
              <th>Action  </th>
            </tr>
          </thead>
          <tbody>
            {productCats &&
              productCats.map((ele) => (
                <tr>
                  <td>{ele.categoryId}</td>
                  <td>{ele.categoryName}</td>
                  <td>{ele.product[0].productId}</td>
                  <td>{ele.product[0].productName}</td>
                  <td>{ele.product[0].productDescription}</td>
                  <td>{ele.product[0].productPrice}</td>
                  <td>{ele.product[0].quantity}</td>
                  <td>{ele.product[0].status}</td>
                 
                  <td>
                  
                   <Button onClick={()=>dispatch(deleteProductCat(ele.categoryId))}>Delete</Button>
                  <button> <Link to={`/update/${ele.categoryId}`}>Edit</Link>
                  </button>
                 </td>
                </tr>
              ))}

            {/* </div>
        </div> */}
          </tbody>
        </table>
      </div>
      </div>
    </React.Fragment>
  );
};

export default Read;
