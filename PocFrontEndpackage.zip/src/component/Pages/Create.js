import React from "react";
import { useDispatch  } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { createProductCat } from "../../feature/productcatslice";
import "./Create.css"
import Button from "../UI/Button"




const Create = () => {
  
  

    const navigate = useNavigate();
  const productsCatInt = {
    categoryId: 0,
    categoryName: "",
    product: [
      {
        productId: 0,
        productName: "",
        productDescription: "",
        productPrice: "",
        quantity: 0,
        status: "",
      },
    ],
  };

  const { register, handleSubmit } = useForm();

  
  const dispatch = useDispatch();

  const handleProductSubmit = (data) => {
    // console.log('form data ', data)
    //console.log("data.categoryName ",data.categoryName)
    productsCatInt.categoryName = data.categoryName;
    productsCatInt.product = [
      {
        productId: 0,
        categoryName: data.categoryName,
        productName: data.productName,
        productDescription: data.productDescription,
        productPrice: data.productPrice,
        quantity: data.quantity,
        status: data.status,
      },
    ];

    console.log("productsCatInt", productsCatInt);
    dispatch(createProductCat(productsCatInt));
    navigate("/read")
  };

  return (
    <div>
      <div className="MainDiv">
      <h2 className="my-2">Create Product</h2>
        <form
          className="w-50 mx-auto"
          onSubmit={handleSubmit(handleProductSubmit)}
        >
          <div className="mb-3">
            <label className="form-lable">categoryName </label>
            <input
              type="text"
              name="categoryName"
              class="form-control"
              {...register("categoryName")}
            />
           
          </div>

          <div className="mb-3">
            <label className="form-lable">productName </label>
            <input
              type="text"
              name="productName"
              class="form-control"
              {...register("productName")}
            />
          </div>
          <div className="mb-3">
            <label className="form-lable">productDescription </label>
            <input
              type="text"
              name="productDescription"
              class="form-control"
              {...register("productDescription")}
            />
          </div>
          <div className="mb-3">
            <label className="form-lable">productPrice </label>
            <input
              type="text"
              name="productPrice"
              class="form-control"
              {...register("productPrice")}
            />
          </div>
          <div className="mb-3">
            <label className="form-lable">quantity </label>
            <input
              type="number"
              name="quantity"
              class="form-control"
              {...register("quantity")}
            />
          </div>
          <div> </div>
          <div className="mb-3">
            <label className="form-lable">status </label>
            <input
              type="text"
              name="status"
              class="form-control"
              {...register("status")}
            />
          </div>

          <Button type="submit">Submit</Button>
        </form>
      </div>
    </div>
  );
};

export default Create;
