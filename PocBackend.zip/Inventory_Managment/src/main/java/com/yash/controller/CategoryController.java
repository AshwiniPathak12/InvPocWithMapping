package com.yash.controller;

import java.util.List;

import com.yash.model.Category;
import com.yash.model.Product;
import com.yash.repository.CategoryRepo;
import com.yash.repository.ProductRepo;
import com.yash.service.CategoryService;
import com.yash.service.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("category")
@CrossOrigin("*")
public class CategoryController {

	@Autowired
	CategoryService categoryService;

	@Autowired
	CategoryRepo categoryRepo;

	@Autowired
	ProductRepo productRepo;

	// http://localhost:8080/category/getAll
	// creating a get mapping that retrieves all the detail from the database
	@GetMapping("/getAll")
	public List<Category> getAllCategoryList() {
		return categoryService.getAllCategory();
	}

	// creating a get mapping that retrieves the detail of a specific product
	// http://localhost:8080/category/getById/7
	@GetMapping("/getById/{categoryId}")
	public Category getCategoryById(@PathVariable int categoryId) throws ResourceNotFoundException {
		return categoryService.getCategoryById(categoryId);

	}

	// http://localhost:8080/category/saveCategory
	// creating post mapping that post the product detail in the database
	@PostMapping("saveCategory")
	public ResponseEntity<Category> saveCategoryDeatils(@RequestBody Category category) {
//System.out.println("category is: " +category.getProduct());
		Category saveCategory = categoryService.saveCategory(category);
		return new ResponseEntity<Category>(saveCategory, HttpStatus.CREATED);

	}

	// http://localhost:8080/category/deleteProduct/16
	// creating a delete mapping that deletes a specified product
	@DeleteMapping("deleteProduct/{categoryId}")
	public String deleteCategory(@PathVariable int categoryId) {
		return categoryService.deleteCategory(categoryId);

	}

	// creating put mapping that updates the product details
	// http://localhost:8080/category/updateCategory/16
	@PutMapping("updateCategory/{categoryId}")
	public ResponseEntity<Category> updateCategory(@RequestBody Category category, @PathVariable int categoryId) {
		Category category1 = categoryService.getCategoryById(categoryId);

		category1.setCategoryId(category.getCategoryId());
		category1.setCategoryName(category.getCategoryName());
		category1.setProduct(category.getProduct());

		Category updateCategory = categoryService.saveCategory(category1);
		return ResponseEntity.ok().body(updateCategory);

	}
	
	// http://localhost:8083/category/search?query=key
	@GetMapping("/search")
	public ResponseEntity<List<Category>> searchCategory(@RequestParam("query") String query) {
		return ResponseEntity.ok(categoryService.searchCat(query));
	}

}
