import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { createProductCat } from "../../feature/productcatslice";
import axios from "axios";
import "./Update.css"
import Button from "../UI/Button"

const Update = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { productCats, loading } = useSelector((state) => state.app);

  const { register, handleSubmit } = useForm();

  const [updateData, setUpdateData] = useState({
    categoryId: 0,
    categoryName: "",
    product: [
      {
        productId: 0,
        productName: "",
        productDescription: "",
        productPrice: "",
        quantity: 0,
        status: "",
      },
    ],
  });

  useEffect(() => {
    axios
      .get(`http://localhost:8083/category/getById/` + categoryId)
      .then((res) => setUpdateData(res.data));
  }, []);

  console.log("updateData", updateData);

  const productSubmitHandler = (e) => {
    e.preventDefault();
    axios
      .put(
        `http://localhost:8083/category/updateCategory/` + categoryId,
        updateData
      )
      .then((res) => {
        alert("Updated");
        navigate("/read");
      });
  };

 

  return (
    <div>
      <div className="main">
        <h2 className="my-2">Update Product</h2>
        <form className="w-50 mx-auto" onSubmit={productSubmitHandler}>
        <div className="formd">
          <div className="mb-4">
            <label >categoryName</label>
            <input
              type="text"
              name="categoryName"
              placeholder="enter categoryName"
              value={updateData.categoryName}
              onChange={(e) =>
                setUpdateData({ ...updateData, categoryName: e.target.value })
              }
            />
          </div>

          <div className="mb-4">
            <label >productName</label>

            <input
              type="text"
              name="productName"
              placeholder="enter productName"
              value={updateData.product[0].productName}
              onChange={(e) => {
                  setUpdateData({
                   ...updateData,
                  
                   product: [{
                    ...updateData.product[0],
                      ...updateData.product[0].productName,
                     productName: e.target.value,
                  }],
                 })
              }}
              //  onChange={(e) =>
              //   setUpdateData({
              //     ...updateData,
              //     productDescription: e.target.value,
              //   })
              // }
             
            />
          </div>

          <div className="mb-4">
            <label >productDescription</label>
            <input
              type="text"
              name="productDescription"
              placeholder="enter productDescription"
              value={updateData.product[0].productDescription}

              onChange={(e) => {
                  setUpdateData({
                   ...updateData,
                   product:[ {
                    ...updateData.product[0],
                     ...updateData.product[0].productDescription,
                     productDescription: e.target.value,
                  }],
                 })
              }}
              // onChange={(e) =>
              //   setUpdateData({
              //     ...updateData,
              //     productDescription: e.target.value,
              //   })
              // }
            />
          </div>

          <div className="mb-4">
            <label>productPrice</label>
            <input
              type="text"
              name="productPrice"
              placeholder="enter productPrice"
              value={updateData.product[0].productPrice}

              onChange={(e) => {
                  setUpdateData({
                   ...updateData,
                   product:[ {
                    ...updateData.product[0],
                     ...updateData.product[0].productPrice,
                     productPrice: e.target.value,
                  }],
                 })
              }}
              // onChange={(e) =>
              //   setUpdateData({ ...updateData, productPrice: e.target.value })
              // }
            />
          </div>

          <div className="mb-4">
            <label >quantity</label>
            <input
              type="number"
              name="quantity"
              placeholder="enter quantity"
              value={updateData.product[0].quantity}

              onChange={(e) => {
                  setUpdateData({
                   ...updateData,
                   product:[ {
                    ...updateData.product[0],
                     ...updateData.product[0].quantity,
                     quantity: e.target.value,
                  }],
                 })
              }}
              // onChange={(e) =>
              //   setUpdateData({ ...updateData, quantity: e.target.value })
              // }
            />
          </div>

          <div className="mb-4">
            <label >status</label>
            <input
              type="text"
              name="status"
              placeholder="enter status"
              value={updateData.product[0].status}
              onChange={(e) => {
                  setUpdateData({
                   ...updateData,
                   product:[ {
                    ...updateData.product[0],
                     ...updateData.product[0].status,
                     status: e.target.value,
                  }],
                 })
              }}
              // onChange={(e) =>
              //   setUpdateData({ ...updateData, status: e.target.value })
              // }
            />
          </div>

          <Button type="submit">Submit</Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Update;
